import EmployeeSingle from "../../../src/Components/AboutPage/EmployeeSingle"

function EmployeeSinglePage() {
  
  return (
   
    <>
      <EmployeeSingle />
    </>
  )
}

export default EmployeeSinglePage
