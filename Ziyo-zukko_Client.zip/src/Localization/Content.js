import uz from "./uz.js";
import ru from "./ru.js";
import en from "./en.js";

const lang = { uz, ru, en };

export default lang;
