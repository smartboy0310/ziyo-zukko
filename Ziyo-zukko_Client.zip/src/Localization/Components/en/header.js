const header = {
   for_blinders: 'for the visually impaired',
   search: "what are you searching ...",
   heading: "STATE SERVICE OF THE REPUBLIC OF UZBEKISTAN FOR MONITORING HAZARDOUS GEOLOGICAL PROCESSES",
   address: "100011, Tashkent city, Abdulla Qodiri Street, 11",
   home: "Home",
   about: "About US",
   gallery: "Photo Gallery",
   news: "News",
   contact: "Contact", 
   sub_list_one: {
      legal_status: "Legal status",
      charter: "Charter",
      structure: "Structure",
      management: "Management",      
      open_data: "Open data",
      department: "Manadgement Department"
   },
   footer: {
      address: "Our address:",
      address_title: "100041, Uzbekistan Tashkent city, Olimlar-64 street",
      phone: "Phone:",
      faks: "Faks"
   }
};

export default header;
