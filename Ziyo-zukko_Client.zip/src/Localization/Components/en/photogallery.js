const photogallery = {
    heading: "Photo gallery"
};

export default photogallery;
