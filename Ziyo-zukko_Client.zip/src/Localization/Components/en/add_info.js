const add__info = {
   landslides: "Landslides",
   funnels: "Funnels",
   collapses: "Collapses",
   avalanche: "Avalanche"
}
export default add__info