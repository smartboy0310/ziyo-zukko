const homeNews = {
    heading: "Latest news",
    more: "All news"
}

export default homeNews