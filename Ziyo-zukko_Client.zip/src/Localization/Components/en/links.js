const links = {
    heading: "Полезные ссылки"
}

export default links