const add__info = {
   landslides: "Оползни",
   funnels: "Воронки",
   collapses: "Обвалы",
   avalanche: "Обрушения"
}
export default add__info