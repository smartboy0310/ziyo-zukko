const photogallery = {
    heading: "Фотогалерея"
};

export default photogallery;
