const homeNews = {
    heading: "Последние новости",
    more: "Все новости"
}

export default homeNews