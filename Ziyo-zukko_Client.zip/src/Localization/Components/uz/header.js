const header = {
   for_blinders: "ko'zi ojizlar uchun",
   search: "siz nimani izlayapsiz...",
   heading: "Ziyo-Zukko nodavlat ta'lim maskani",
   address: "100011, Toshkent shahar,  Abdulla Qodiriy ko’chasi, 11-uy",
   home: "Bosh sahifa",
   about: "Biz haqimizda",
   gallery: "Fotogalereya",
   news: "Yangliklar",
   contact: "Kontaktlar",
   sub_list_one: {
      legal_status: "Huquqiy holat",
      charter: "Nizom",
      structure: "Tuzilishi",
      management: "Boshqaruv",      
      open_data: "Ochiq ma'lumotlar",
      department: "Boshqaruv bo'limi"
   },
   footer: {
      address: "Bizning manzil:",
      address_title: "100041, Oʻzbekiston Toshkent shahri, Olimlar ko‘chasi, 64-uy",
      phone: "Telefon:",
      faks: "Faks"
   }
};

export default header;
