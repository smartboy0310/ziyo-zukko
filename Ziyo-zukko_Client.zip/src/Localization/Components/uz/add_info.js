const add__info = {
   landslides: "Ko'chkilar",
   funnels: "Tutun  trubinas",
   collapses: "Qulab tushadi",
   avalanche: "Qor ko'chkisi"
}
export default add__info