const homeNews = {
    heading: "So'ngi yangiliklar",
    more: "Barcha yangiliklar"
}

export default homeNews