const photogallery = {
    heading: "Fotogalereya"
};

export default photogallery;
