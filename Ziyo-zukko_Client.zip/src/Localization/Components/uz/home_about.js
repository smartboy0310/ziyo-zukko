const home_about = {
   about: "Xizmatlar haqida",
   heading: "Xavfli geologik jarayonlarni kuzatish Davlat xizmati (XGJKDX)ning asosiy vazifalari:",
   tasks: {
      one: "1.Xavfli geologik jarayonlar rivojlanadigan joylarni aniqlash va ularning faollashishini oldindan belgilash;",
      two: "2.Xavfli geologik jarayonlarning vujudga kelishi va rivojlanishini muntazam kuzatishni tashkil etish, mahalliy davlat hokimiyati va boshqaruv organlarini, manfaatdor vazirliklar, davlat qo’mitalari hamda idoralarni ularning ro’y berishi mumkin bo’lgan falokatlari va oqibatlari to’g’risida xabardor qilish va ogohlantirish;",
      three: "3.Davlat kuzatish xizmatining yozma ko’rsatiladigan, shuningdek xulosalarida bayon etilgan talablarning respublikaning barcha vazirliklari, davlat qo’mitalari, idoralari, ularning qaysi idoraga tegishli ega ekanligidan va mulkchilik shaklidan qat’iy nazar, korxonalari.",
      four: "4.Xavfli geologik jarayonlarning yangi manbaalarining shakllanishini oldini olish maqsadida ularning kuchayishi mumkin bo’lgan mintaqalardagi hududlardan oqilona foydalanish bo’yicha ko’rsatmalar tayyorlash va berish.",
      five: "Ko’rsatiladigan xizmatlar:",
      six: "Xavfli geologik jarayonlarning ro’y berishi mumkin bo’lgan falokatlari va oqibatlarini oldini olish maqsadida ularning kuchayishi mumkin bo’lgan mintaqalardagi hududlardan oqilona foydalanish bo’yicha"
   }
}

export default home_about