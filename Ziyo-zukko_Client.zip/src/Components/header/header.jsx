import Image from 'next/image';
import Link from 'next/link';
import React, { useRef, useState, useEffect } from 'react';
import Content from '../../Localization/Content';
import { useDispatch, useSelector } from 'react-redux';
import { useRouter } from 'next/router';

import Logo from '../../Assets/images/logo.svg';
import LocationImg from '../../Assets/images/map-icon.svg';
import humburgerImg from '../../Assets/images/humburger.svg';
import closeImg from '../../Assets/images/close.svg';

const Header = () => {
	const router = useRouter()
  	const pageRoute = router.asPath
	  
		const [checkBtn, setCheckBtn] = useState(true);

	const langValue = useRef();

	const dispatch = useDispatch();

	const {
		count: { lang },
	} = useSelector((state) => state);

	function getLang() {
		dispatch({ type: window.localStorage.getItem('lang') || 'uz' });
	}

	langValue.current = getLang;

	useEffect(() => {
		langValue.current();
	}, []);

	const { header: h } = Content[lang];

	const clickBtn = () => {
		setCheckBtn(!checkBtn);
	};
	const closeMobileNavbar = () => {
		setCheckBtn(true);
	}

	return (
		<>
			<div className="container">
				<div className="header__top">
					<div className="phone">
						<a className="phone__number" href="tel:+998712443581">
							+998 (71) 2443581
						</a>
					</div>
					<div className="email__address">
						<a href="mailto:ziyo-zukko@gmail.com" className="email">
							ziyo-zukko@gmail.com
						</a>
					</div>
					<div className="work__time">
						<time className="time__info">Du-Sha 8:00 - 18:00</time>
					</div>

					<div className="lang__box">
						<ul className="lang__list active__lang">
							<li
								className={
									lang === 'uz'
										? 'lang__item lang__item--active'
										: 'lang__item'
								}
								onClick={() => {
									dispatch({ type: 'uz' });
								}}
							>
								O’zbekcha
								<span className="under_line"></span>
							</li>
							<li
								className={
									lang == 'ru'
										? 'lang__item lang__item--active'
										: 'lang__item'
								}
								onClick={() => {
									dispatch({ type: 'ru' });
								}}
							>
								Русский
								<span className="under_line"></span>
							</li>
						</ul>
						<ul className="lang__list mobile__lang">
							<li
								className={
									lang === 'uz'
										? 'lang__item lang__item--active'
										: 'lang__item'
								}
								onClick={() => {
									dispatch({ type: 'uz' });
								}}
							>
								Uz
								<span className="under_line"></span>
							</li>
							<li
								className={
									lang == 'ru'
										? 'lang__item lang__item--active'
										: 'lang__item'
								}
								onClick={() => {
									dispatch({ type: 'ru' });
								}}
							>
								Ру
								<span className="under_line"></span>
							</li>
						</ul>
					</div>
					<div className="header__address">
						<a
							href="https://2gis.uz/uz/tashkent/firm/70000001036919062"
							rel="noreferrer"
							className="header__address--link"
						>
							<div className="location__img">
								<Image
									className="header__loc__img"
									src={LocationImg}
									alt="Location icon"
									maxwidth={25}
									maxheight={25}
									objectFit="contain"
								/>
							</div>
							<p className="location__discription">{h.address}</p>
						</a>
					</div>
				</div>
				<div className="header__bottom">
					<div className="header__logo__info">
						<Link href="/">
							<a className="logo__link">
								<div className="logo__box">
									<Image
										className="logo__img"
										src={Logo}
										alt="School logo"
										width={90}
										height={90}
										objectFit="cover"
									/>
								</div>
								<p className="header__heading">{h.heading}</p>
							</a>
						</Link>
					</div>

					<div className={!checkBtn ? "navbar-and-social active__mobile__navbar" : "navbar-and-social"}>
						
					<div className="mobile__navbar__box">
					<nav className="header__navbar close-desktop__navbar">
						<ul className="navbar__list">
							<li className="navbar__item">
								<Link href="/">
									<a
										onClick={closeMobileNavbar}
										className={`navbar__item-link ${
											router.pathname == '/'
												? 'navbar__item-link--active'
												: ''
										}`}
									>
										{h.home}
									</a>
								</Link>
								<span className="navbar_line"></span>
							</li>
							<li className="navbar__item">
								<Link href="/about">
									<a
									onClick={closeMobileNavbar}
										className={`navbar__item-link ${
											router.pathname == '/'
												? 'navbar__item-link--active'
												: ''
										}`}
									>
										{h.about}
									</a>
								</Link>
								<span className="navbar_line"></span>
							</li>
							<li className="navbar__item">
								<Link href="/gallery">
									<a
									onClick={closeMobileNavbar}
										className={`navbar__item-link ${
											router.pathname == '/'
												? 'navbar__item-link--active'
												: ''
										}`}
									>
										{h.gallery}
									</a>
								</Link>
								<span className="navbar_line"></span>
							</li>
							<li className="navbar__item">
								<Link href="/news">
									<a
									onClick={closeMobileNavbar}
										className={`navbar__item-link ${
											router.pathname == '/'
												? 'navbar__item-link--active'
												: ''
										}`}
									>
										{h.news}
									</a>
								</Link>
								<span className="navbar_line"></span>
							</li>

							<li className="navbar__item">
								<Link href="/contact">
									<a
									onClick={closeMobileNavbar}
										className={`navbar__item-link ${
											router.pathname == '/'
												? 'navbar__item-link--active'
												: ''
										}`}
									>
										{h.contact}
									</a>
								</Link>
								<span className="navbar_line"></span>
							</li>
						</ul>
					</nav>
					<div className="header__social close-desktop__navbar">
						<ul className="social__list">
							<li className="social__item">
								<a
									className="social__link"
									href="https://www.facebook.com/"
									rel="noreferrer"
								>
									<div className="social__content"></div>
								</a>
							</li>
							<li className="social__item">
								<a
									className="social__link"
									href="https://www.instagram.com/"
									rel="noreferrer"
								>
									<div className="social__content"></div>
								</a>
							</li>
							<li className="social__item">
								<a
									className="social__link"
									href="https://web.telegram.org/"
									rel="noreferrer"
								>
									<div className="social__content"></div>
								</a>
							</li>
						</ul>
					</div>
					</div>
					</div>
					<div className="reponsev__navbar">
						<div className="openNavar__btn" onClick={clickBtn}>
							<div className={checkBtn ? "navbar__btn__box active__btn" : "navbar__btn__box"}>
								<Image
									src={humburgerImg}
									alt="Show navbar pic"
								/>
							</div>
							<div className={!checkBtn ? "navbar__btn__box active__btn" : "navbar__btn__box"}>
								<Image
									src={closeImg}
									alt="Show navbar pic"
								/>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div className="header__line"></div>
		</>
	);
};

export default Header;
