"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 9585:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: external "redux"
const external_redux_namespaceObject = require("redux");
;// CONCATENATED MODULE: external "next-redux-wrapper"
const external_next_redux_wrapper_namespaceObject = require("next-redux-wrapper");
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./store/store.js



const initialState = {
    lang: "uz"
};
const count = function reducer(state = initialState, action) {
    switch(action.type){
        case "en":
            window.localStorage.setItem("lang", "en");
            return {
                ...state,
                lang: "en"
            };
        case "ru":
            window.localStorage.setItem("lang", "ru");
            return {
                ...state,
                lang: "ru"
            };
        case "uz":
            window.localStorage.setItem("lang", "uz");
            return {
                ...state,
                lang: "uz"
            };
        default:
            return state;
    }
};
const combineReducer = (0,external_redux_namespaceObject.combineReducers)({
    count
});
const initialStore = ()=>{
    return (0,external_redux_namespaceObject.createStore)(combineReducer);
};
const wrapper = (0,external_next_redux_wrapper_namespaceObject.createWrapper)(initialStore);

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./src/Localization/Content.js + 21 modules
var Content = __webpack_require__(605);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
;// CONCATENATED MODULE: external "next/router"
const router_namespaceObject = require("next/router");
;// CONCATENATED MODULE: ./src/Assets/images/logo.svg
/* harmony default export */ const logo = ({"src":"/_next/static/media/logo.a4d1b2a0.svg","height":699,"width":699});
;// CONCATENATED MODULE: ./src/Components/footer/footer.jsx








const Footer = ()=>{
    const router = (0,router_namespaceObject.useRouter)();
    const langValue = (0,external_react_.useRef)();
    const dispatch = (0,external_react_redux_.useDispatch)();
    const { count: { lang  } ,  } = (0,external_react_redux_.useSelector)((state)=>state
    );
    function getLang() {
        dispatch({
            type: window.localStorage.getItem('lang') || 'uz'
        });
    }
    langValue.current = getLang;
    (0,external_react_.useEffect)(()=>{
        langValue.current();
    }, []);
    const { header: h  } = Content/* default */.Z[lang];
    return(/*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("footer", {
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "footer__bottom",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "footer__logo__info",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "/",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    className: "footer__logo__link",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "footer__logo__box",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                                className: "footer__logo__img",
                                                src: logo,
                                                alt: "Ministry logo",
                                                width: 90,
                                                height: 90,
                                                objectFit: "cover"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "footer__heading",
                                            children: h.heading
                                        })
                                    ]
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                            className: "footer__navbar",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: "footer__navbar__list",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "footer__navbar__item",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/about",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: `footer__navbar__item-link ${router.pathname == '/' ? 'footer__navbar__item-link--active' : ''}`,
                                                children: h.about
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "footer__navbar__item",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/gallery",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: `footer__navbar__item-link ${router.pathname == '/' ? 'footer__navbar__item-link--active' : ''}`,
                                                children: h.gallery
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "footer__navbar__item",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/news",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: `footer__navbar__item-link ${router.pathname == '/' ? 'footer__navbar__item-link--active' : ''}`,
                                                children: h.news
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "footer__navbar__item",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/contact",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: `footer__navbar__item-link ${router.pathname == '/' ? 'footer__navbar__item-link--active' : ''}`,
                                                children: h.contact
                                            })
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "footer__social",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: "footer__social__list",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "footer__social__item",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            className: "footer__social__link",
                                            href: "https://www.facebook.com/",
                                            rel: "noreferrer",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "footer__social__content"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "footer__social__item",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            className: "footer__social__link",
                                            href: "https://www.instagram.com/",
                                            rel: "noreferrer",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "footer__social__content"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "footer__social__item",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            className: "footer__social__link",
                                            href: "https://web.telegram.org/",
                                            rel: "noreferrer",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "footer__social__content"
                                            })
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                })
            })
        })
    }));
};
/* harmony default export */ const footer = (Footer);

;// CONCATENATED MODULE: external "react-use"
const external_react_use_namespaceObject = require("react-use");
;// CONCATENATED MODULE: ./src/Components/GoTop/GoTop.jsx



function GoTop() {
    const { y: pageYOffset  } = (0,external_react_use_namespaceObject.useWindowScroll)();
    const { 0: visible , 1: setVisible  } = (0,external_react_.useState)(false);
    (0,external_react_.useEffect)(()=>{
        if (pageYOffset > 500) {
            setVisible(true);
        } else {
            setVisible(false);
        }
    }, [
        pageYOffset
    ]);
    const scrollToTop = ()=>window.scrollTo({
            top: 0,
            behavior: 'smooth'
        })
    ;
    if (!visible) {
        return false;
    }
    return(/*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "scroll__go-top",
            onClick: scrollToTop,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                className: "svg-icon ",
                viewBox: "0 0 1024 1024",
                xmlns: "http://www.w3.org/2000/svg",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        d: "M683.52 597.333a33.997 33.997 0 0 1-24.132-10L512.853 440.814 366.32 587.332a34.133 34.133 0 1 1-48.265-48.264L488.721 368.4a34.133 34.133 0 0 1 48.265 0l170.666 170.667a34.133 34.133 0 0 1-24.132 58.265z",
                        fill: "#2C6BAF"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        d: "M512.853 955.733H512c-121.89 0-227.584-43.878-314.146-130.44C111.872 739.277 68.267 633.89 68.267 512c0-121.856 43.588-227.55 129.536-314.112C284.45 111.855 390.144 68.267 512 68.267c121.907 0 227.294 43.605 313.259 129.587C911.838 284.399 955.733 390.093 955.733 512c0 121.924-43.912 227.345-130.491 313.344-85.914 86.494-191.028 130.39-312.389 130.39zM512 102.4c-112.52 0-210.125 40.243-290.065 119.62C142.643 301.875 102.4 399.48 102.4 512c0 112.503 40.226 209.783 119.586 289.16C301.91 881.085 399.496 921.6 512 921.6h.853c111.94 0 208.913-40.5 288.24-120.405C881.082 721.766 921.6 624.503 921.6 512c0-112.52-40.533-210.09-120.474-290.014C721.783 142.626 624.521 102.4 512 102.4z",
                        fill: "#2C6BAF"
                    })
                ]
            })
        })
    }));
}
/* harmony default export */ const GoTop_GoTop = (GoTop);

;// CONCATENATED MODULE: ./src/Assets/images/map-icon.svg
/* harmony default export */ const map_icon = ({"src":"/_next/static/media/map-icon.8b659e40.svg","height":132,"width":108});
;// CONCATENATED MODULE: ./src/Assets/images/humburger.svg
/* harmony default export */ const humburger = ({"src":"/_next/static/media/humburger.bc3db337.svg","height":40,"width":40});
;// CONCATENATED MODULE: ./src/Assets/images/close.svg
/* harmony default export */ const images_close = ({"src":"/_next/static/media/close.655eac09.svg","height":35,"width":35});
;// CONCATENATED MODULE: ./src/Components/header/header.jsx











const Header = ()=>{
    const router = (0,router_namespaceObject.useRouter)();
    const pageRoute = router.asPath;
    const { 0: checkBtn , 1: setCheckBtn  } = (0,external_react_.useState)(true);
    const langValue = (0,external_react_.useRef)();
    const dispatch = (0,external_react_redux_.useDispatch)();
    const { count: { lang  } ,  } = (0,external_react_redux_.useSelector)((state)=>state
    );
    function getLang() {
        dispatch({
            type: window.localStorage.getItem('lang') || 'uz'
        });
    }
    langValue.current = getLang;
    (0,external_react_.useEffect)(()=>{
        langValue.current();
    }, []);
    const { header: h  } = Content/* default */.Z[lang];
    const clickBtn = ()=>{
        setCheckBtn(!checkBtn);
    };
    const closeMobileNavbar = ()=>{
        setCheckBtn(true);
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "header__top",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "phone",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    className: "phone__number",
                                    href: "tel:+998712443581",
                                    children: "+998 (71) 2443581"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "email__address",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "mailto:ziyo-zukko@gmail.com",
                                    className: "email",
                                    children: "ziyo-zukko@gmail.com"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "work__time",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("time", {
                                    className: "time__info",
                                    children: "Du-Sha 8:00 - 18:00"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "lang__box",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        className: "lang__list active__lang",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                className: lang === 'uz' ? 'lang__item lang__item--active' : 'lang__item',
                                                onClick: ()=>{
                                                    dispatch({
                                                        type: 'uz'
                                                    });
                                                },
                                                children: [
                                                    "O’zbekcha",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "under_line"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                className: lang == 'ru' ? 'lang__item lang__item--active' : 'lang__item',
                                                onClick: ()=>{
                                                    dispatch({
                                                        type: 'ru'
                                                    });
                                                },
                                                children: [
                                                    "Русский",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "under_line"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        className: "lang__list mobile__lang",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                className: lang === 'uz' ? 'lang__item lang__item--active' : 'lang__item',
                                                onClick: ()=>{
                                                    dispatch({
                                                        type: 'uz'
                                                    });
                                                },
                                                children: [
                                                    "Uz",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "under_line"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                className: lang == 'ru' ? 'lang__item lang__item--active' : 'lang__item',
                                                onClick: ()=>{
                                                    dispatch({
                                                        type: 'ru'
                                                    });
                                                },
                                                children: [
                                                    "Ру",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "under_line"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "header__address",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    href: "https://2gis.uz/uz/tashkent/firm/70000001036919062",
                                    rel: "noreferrer",
                                    className: "header__address--link",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "location__img",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                                className: "header__loc__img",
                                                src: map_icon,
                                                alt: "Location icon",
                                                maxwidth: 25,
                                                maxheight: 25,
                                                objectFit: "contain"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "location__discription",
                                            children: h.address
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "header__bottom",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "header__logo__info",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "/",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                        className: "logo__link",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "logo__box",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                                    className: "logo__img",
                                                    src: logo,
                                                    alt: "School logo",
                                                    width: 90,
                                                    height: 90,
                                                    objectFit: "cover"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "header__heading",
                                                children: h.heading
                                            })
                                        ]
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: !checkBtn ? "navbar-and-social active__mobile__navbar" : "navbar-and-social",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "mobile__navbar__box",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                            className: "header__navbar close-desktop__navbar",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                className: "navbar__list",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                        className: "navbar__item",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                                href: "/",
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                    onClick: closeMobileNavbar,
                                                                    className: `navbar__item-link ${router.pathname == '/' ? 'navbar__item-link--active' : ''}`,
                                                                    children: h.home
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "navbar_line"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                        className: "navbar__item",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                                href: "/about",
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                    onClick: closeMobileNavbar,
                                                                    className: `navbar__item-link ${router.pathname == '/' ? 'navbar__item-link--active' : ''}`,
                                                                    children: h.about
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "navbar_line"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                        className: "navbar__item",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                                href: "/gallery",
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                    onClick: closeMobileNavbar,
                                                                    className: `navbar__item-link ${router.pathname == '/' ? 'navbar__item-link--active' : ''}`,
                                                                    children: h.gallery
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "navbar_line"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                        className: "navbar__item",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                                href: "/news",
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                    onClick: closeMobileNavbar,
                                                                    className: `navbar__item-link ${router.pathname == '/' ? 'navbar__item-link--active' : ''}`,
                                                                    children: h.news
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "navbar_line"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                        className: "navbar__item",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                                href: "/contact",
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                    onClick: closeMobileNavbar,
                                                                    className: `navbar__item-link ${router.pathname == '/' ? 'navbar__item-link--active' : ''}`,
                                                                    children: h.contact
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "navbar_line"
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "header__social close-desktop__navbar",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                className: "social__list",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                        className: "social__item",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                            className: "social__link",
                                                            href: "https://www.facebook.com/",
                                                            rel: "noreferrer",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "social__content"
                                                            })
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                        className: "social__item",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                            className: "social__link",
                                                            href: "https://www.instagram.com/",
                                                            rel: "noreferrer",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "social__content"
                                                            })
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                        className: "social__item",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                            className: "social__link",
                                                            href: "https://web.telegram.org/",
                                                            rel: "noreferrer",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "social__content"
                                                            })
                                                        })
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "reponsev__navbar",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "openNavar__btn",
                                    onClick: clickBtn,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: checkBtn ? "navbar__btn__box active__btn" : "navbar__btn__box",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                                src: humburger,
                                                alt: "Show navbar pic"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: !checkBtn ? "navbar__btn__box active__btn" : "navbar__btn__box",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                                src: images_close,
                                                alt: "Show navbar pic"
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "header__line"
            })
        ]
    }));
};
/* harmony default export */ const header = (Header);

;// CONCATENATED MODULE: ./src/Components/layout/layout.jsx





const Layout = ({ children  })=>{
    const router = (0,router_namespaceObject.useRouter)();
    const pageRoute = router.asPath;
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("header", {
                className: pageRoute == '/about' || pageRoute == '/about/single' ? "header about_page" : pageRoute == '/gallery' ? "header gallery_page" : pageRoute == '/news' || pageRoute == '/news/single' ? "header news_page" : pageRoute == '/contact' ? "header contact_page" : "header",
                id: "header",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(header, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(GoTop_GoTop, {})
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                children: children
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("footer", {
                className: "footer",
                children: /*#__PURE__*/ jsx_runtime_.jsx(footer, {})
            })
        ]
    }));
};
/* harmony default export */ const layout = (Layout);

// EXTERNAL MODULE: ./src/Context/GlobalState.jsx
var GlobalState = __webpack_require__(2469);
;// CONCATENATED MODULE: ./pages/_app.js





function MyApp({ Component , pageProps  }) {
    return(/*#__PURE__*/ jsx_runtime_.jsx(GlobalState/* Provider */.z, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(layout, {
            children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                ...pageProps
            })
        })
    }));
}
/* harmony default export */ const _app = (wrapper.withRedux(MyApp));


/***/ }),

/***/ 2469:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ Provider),
/* harmony export */   "_": () => (/* binding */ Context)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const Context = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(null);
function Provider({ children  }) {
    const { 0: techSingle , 1: setTechSingle  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const { 0: newSingle , 1: setNewSingle  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Context.Provider, {
        value: {
            techSingle,
            setTechSingle,
            newSingle,
            setNewSingle
        },
        children: children
    }));
}



/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [675,676,664,605], () => (__webpack_exec__(9585)));
module.exports = __webpack_exports__;

})();