"use strict";
exports.id = 927;
exports.ids = [927];
exports.modules = {

/***/ 6927:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/direktor.33d14553.jpg","height":464,"width":696,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAAAwX/2gAMAwEAAhADEAAAAKkT2//EABsQAAIDAAMAAAAAAAAAAAAAAAECAxITACFR/9oACAEBAAE/ANo2DyYJYLUMe28PP//EABgRAAIDAAAAAAAAAAAAAAAAAAECABJy/9oACAECAQE/AKgqmBP/xAAWEQEBAQAAAAAAAAAAAAAAAAACAQD/2gAIAQMBAT8AbRVku//Z"});

/***/ })

};
;