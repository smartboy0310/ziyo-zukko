"use strict";
exports.id = 605;
exports.ids = [605];
exports.modules = {

/***/ 605:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Content)
});

;// CONCATENATED MODULE: ./src/Localization/Components/uz/header.js
const header = {
    for_blinders: "ko'zi ojizlar uchun",
    search: "siz nimani izlayapsiz...",
    heading: "Ziyo-Zukko nodavlat ta'lim maskani",
    address: "100011, Toshkent shahar,  Abdulla Qodiriy ko’chasi, 11-uy",
    home: "Bosh sahifa",
    about: "Biz haqimizda",
    gallery: "Fotogalereya",
    news: "Yangliklar",
    contact: "Kontaktlar",
    sub_list_one: {
        legal_status: "Huquqiy holat",
        charter: "Nizom",
        structure: "Tuzilishi",
        management: "Boshqaruv",
        open_data: "Ochiq ma'lumotlar",
        department: "Boshqaruv bo'limi"
    },
    footer: {
        address: "Bizning manzil:",
        address_title: "100041, Oʻzbekiston Toshkent shahri, Olimlar ko‘chasi, 64-uy",
        phone: "Telefon:",
        faks: "Faks"
    }
};
/* harmony default export */ const uz_header = (header);

;// CONCATENATED MODULE: ./src/Localization/Components/uz/photogallery.js
const photogallery = {
    heading: "Fotogalereya"
};
/* harmony default export */ const uz_photogallery = (photogallery);

;// CONCATENATED MODULE: ./src/Localization/Components/uz/links.js
const links = {
    heading: "Полезные ссылки"
};
/* harmony default export */ const uz_links = (links);

;// CONCATENATED MODULE: ./src/Localization/Components/uz/home-news.js
const homeNews = {
    heading: "So'ngi yangiliklar",
    more: "Barcha yangiliklar"
};
/* harmony default export */ const home_news = (homeNews);

;// CONCATENATED MODULE: ./src/Localization/Components/uz/home_about.js
const home_about = {
    about: "Xizmatlar haqida",
    heading: "Xavfli geologik jarayonlarni kuzatish Davlat xizmati (XGJKDX)ning asosiy vazifalari:",
    tasks: {
        one: "1.Xavfli geologik jarayonlar rivojlanadigan joylarni aniqlash va ularning faollashishini oldindan belgilash;",
        two: "2.Xavfli geologik jarayonlarning vujudga kelishi va rivojlanishini muntazam kuzatishni tashkil etish, mahalliy davlat hokimiyati va boshqaruv organlarini, manfaatdor vazirliklar, davlat qo’mitalari hamda idoralarni ularning ro’y berishi mumkin bo’lgan falokatlari va oqibatlari to’g’risida xabardor qilish va ogohlantirish;",
        three: "3.Davlat kuzatish xizmatining yozma ko’rsatiladigan, shuningdek xulosalarida bayon etilgan talablarning respublikaning barcha vazirliklari, davlat qo’mitalari, idoralari, ularning qaysi idoraga tegishli ega ekanligidan va mulkchilik shaklidan qat’iy nazar, korxonalari.",
        four: "4.Xavfli geologik jarayonlarning yangi manbaalarining shakllanishini oldini olish maqsadida ularning kuchayishi mumkin bo’lgan mintaqalardagi hududlardan oqilona foydalanish bo’yicha ko’rsatmalar tayyorlash va berish.",
        five: "Ko’rsatiladigan xizmatlar:",
        six: "Xavfli geologik jarayonlarning ro’y berishi mumkin bo’lgan falokatlari va oqibatlarini oldini olish maqsadida ularning kuchayishi mumkin bo’lgan mintaqalardagi hududlardan oqilona foydalanish bo’yicha"
    }
};
/* harmony default export */ const uz_home_about = (home_about);

;// CONCATENATED MODULE: ./src/Localization/Components/uz/add_info.js
const add__info = {
    landslides: "Ko'chkilar",
    funnels: "Tutun  trubinas",
    collapses: "Qulab tushadi",
    avalanche: "Qor ko'chkisi"
};
/* harmony default export */ const add_info = (add__info);

;// CONCATENATED MODULE: ./src/Localization/uz.js






const uz = {
    header: uz_header,
    photogallery: uz_photogallery,
    links: uz_links,
    homeNews: home_news,
    home_about: uz_home_about,
    add__info: add_info
};
/* harmony default export */ const Localization_uz = (uz);

;// CONCATENATED MODULE: ./src/Localization/Components/ru/header.js
const header_header = {
    for_blinders: 'версия для слабовидящих',
    search: 'что вы ищите...',
    heading: "Ziyo-Zukko — негосударственное образовательное учреждение",
    address: "100011, г. Ташкент, улица Абдулла Кадыри, 11",
    home: "Главная",
    gallery: "Фотогалерея",
    about: "O Hас",
    news: "Новости",
    contact: "Контакты",
    sub_list_one: {
        legal_status: "Правовой статус",
        charter: "Устав",
        structure: "Структура",
        management: "Руководство",
        open_data: "Открытые данные",
        department: "Аппарат управленияt"
    },
    footer: {
        address: "Наш адрес:",
        address_title: "100041, Узбекистан г. Ташкент ул.Олимлар-64",
        phone: "Телефон:",
        faks: "Факс:"
    }
};
/* harmony default export */ const ru_header = (header_header);

;// CONCATENATED MODULE: ./src/Localization/Components/ru/photogallery.js
const photogallery_photogallery = {
    heading: "Фотогалерея"
};
/* harmony default export */ const ru_photogallery = (photogallery_photogallery);

;// CONCATENATED MODULE: ./src/Localization/Components/ru/links.js
const links_links = {
    heading: "Полезные ссылки"
};
/* harmony default export */ const ru_links = (links_links);

;// CONCATENATED MODULE: ./src/Localization/Components/ru/home-news.js
const home_news_homeNews = {
    heading: "Последние новости",
    more: "Все новости"
};
/* harmony default export */ const ru_home_news = (home_news_homeNews);

;// CONCATENATED MODULE: ./src/Localization/Components/ru/home_about.js
const home_about_home_about = {
    about: "О службе",
    heading: "Основные задачи Государственной службы по мониторингу опасных геологических процессов (ГСГО):",
    tasks: {
        one: "1. Выявление участков развития опасных геологических процессов и предопределение их активизации;",
        two: "2.Организовать регулярный мониторинг за возникновением и развитием опасных геологических процессов, информировать местные органы власти и управления, профильные министерства, государственные комитеты и ведомства об их возможных бедствиях и последствиях, предостерегать;",
        three: "3. Все министерства, государственные комитеты, агентства республики, независимо от их принадлежности и формы собственности, предприятия, требования которых указаны в письменной форме, а также изложены в заключениях Службы государственного надзора.",
        four: "4. Подготовить и издать методические указания по рациональному использованию территорий в районах возможного появления новых очагов опасных геологических процессов с целью предупреждения образования новых очагов.",
        five: "Услуги, предоставляемые:",
        six: "Рациональное использование территорий в районах возможного возникновения опасных геологических процессов с целью предотвращения потенциальных катастроф и их последствий"
    }
};
/* harmony default export */ const ru_home_about = (home_about_home_about);

;// CONCATENATED MODULE: ./src/Localization/Components/ru/add_info.js
const add_info_add_info = {
    landslides: "Оползни",
    funnels: "Воронки",
    collapses: "Обвалы",
    avalanche: "Обрушения"
};
/* harmony default export */ const ru_add_info = (add_info_add_info);

;// CONCATENATED MODULE: ./src/Localization/ru.js






const ru = {
    header: ru_header,
    photogallery: ru_photogallery,
    links: ru_links,
    homeNews: ru_home_news,
    home_about: ru_home_about,
    add__info: ru_add_info
};
/* harmony default export */ const Localization_ru = (ru);

;// CONCATENATED MODULE: ./src/Localization/Components/en/header.js
const en_header_header = {
    for_blinders: 'for the visually impaired',
    search: "what are you searching ...",
    heading: "STATE SERVICE OF THE REPUBLIC OF UZBEKISTAN FOR MONITORING HAZARDOUS GEOLOGICAL PROCESSES",
    address: "100011, Tashkent city, Abdulla Qodiri Street, 11",
    home: "Home",
    about: "About US",
    gallery: "Photo Gallery",
    news: "News",
    contact: "Contact",
    sub_list_one: {
        legal_status: "Legal status",
        charter: "Charter",
        structure: "Structure",
        management: "Management",
        open_data: "Open data",
        department: "Manadgement Department"
    },
    footer: {
        address: "Our address:",
        address_title: "100041, Uzbekistan Tashkent city, Olimlar-64 street",
        phone: "Phone:",
        faks: "Faks"
    }
};
/* harmony default export */ const en_header = (en_header_header);

;// CONCATENATED MODULE: ./src/Localization/Components/en/photogallery.js
const en_photogallery_photogallery = {
    heading: "Photo gallery"
};
/* harmony default export */ const en_photogallery = (en_photogallery_photogallery);

;// CONCATENATED MODULE: ./src/Localization/Components/en/links.js
const en_links_links = {
    heading: "Полезные ссылки"
};
/* harmony default export */ const en_links = (en_links_links);

;// CONCATENATED MODULE: ./src/Localization/Components/en/home-news.js
const en_home_news_homeNews = {
    heading: "Latest news",
    more: "All news"
};
/* harmony default export */ const en_home_news = (en_home_news_homeNews);

;// CONCATENATED MODULE: ./src/Localization/Components/en/home_about.js
const en_home_about_home_about = {
    about: "About service",
    heading: "The main tasks of the State Service for Monitoring of Hazardous Geological Processes (CGSS):",
    tasks: {
        one: "1. Identification of areas where dangerous geological processes are developing and predetermining their activation;",
        two: "2. Organize regular monitoring of the occurrence and development of hazardous geological processes, inform local authorities and administrations, relevant ministries, state committees and agencies about their possible disasters and consequences; caution;",
        three: "3. All ministries, state committees, agencies of the republic, regardless of their affiliation and form of ownership, enterprises, which are provided in writing by the State Supervision Service, as well as the requirements set forth in the conclusions.",
        four: "4. Prepare and issue guidelines for the rational use of areas in areas where there may be new sources of hazardous geological processes in order to prevent the formation of new sources.",
        five: "Services provided:",
        six: "Rational use of areas in areas where dangerous geological processes are likely to occur in order to prevent potential disasters and their consequences"
    }
};
/* harmony default export */ const en_home_about = (en_home_about_home_about);

;// CONCATENATED MODULE: ./src/Localization/Components/en/add_info.js
const en_add_info_add_info = {
    landslides: "Landslides",
    funnels: "Funnels",
    collapses: "Collapses",
    avalanche: "Avalanche"
};
/* harmony default export */ const en_add_info = (en_add_info_add_info);

;// CONCATENATED MODULE: ./src/Localization/en.js






const en = {
    header: en_header,
    photogallery: en_photogallery,
    links: en_links,
    homeNews: en_home_news,
    home_about: en_home_about,
    add__info: en_add_info
};
/* harmony default export */ const Localization_en = (en);

;// CONCATENATED MODULE: ./src/Localization/Content.js



const lang = {
    uz: Localization_uz,
    ru: Localization_ru,
    en: Localization_en
};
/* harmony default export */ const Content = (lang);


/***/ })

};
;