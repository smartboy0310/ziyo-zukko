module.exports = {
  reactStrictMode: true,
  images: {
    domains: ["ziyozukko.uz"]
  }
}

